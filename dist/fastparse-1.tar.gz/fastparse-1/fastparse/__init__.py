from fastparse import try_parse, fast_parse
